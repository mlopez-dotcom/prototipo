const $=id=>document.getElementById(id);
const tabs=["💡 Descubre","🎯 Convierte","✏️ Crea","🧠 Reflexiona","📘 Guía"];
tabs.forEach((t,i)=>{const b=document.createElement("button");b.textContent=t;b.onclick=()=>show(i);$("nav").appendChild(b)});
function show(i){document.querySelectorAll("section").forEach((s,j)=>s.classList.toggle("on",i===j));[...$("nav").children].forEach((b,j)=>b.classList.toggle("on",i===j))}
show(0);
function bulbs(id,cb){const box=$(id),st=Array(8).fill(0),btns=[];
 [128,64,32,16,8,4,2,1].forEach((v,k)=>{const d=document.createElement("div");d.className="b";const b=document.createElement("button");b.textContent="0";b.setAttribute("aria-label","Foco de valor "+v);b.onclick=()=>{st[k]^=1;b.textContent=st[k];b.classList.toggle("on",!!st[k]);cb(st.reduce((a,x,n)=>a+x*[128,64,32,16,8,4,2,1][n],0),st.join(""))};d.appendChild(b);d.insertAdjacentHTML("beforeend","<small>"+v+"</small>");box.appendChild(d);btns.push(b)});
 return{reset(){st.fill(0);btns.forEach(b=>{b.textContent="0";b.classList.remove("on")})}}}
bulbs("b0",(n,s)=>{$("t0").textContent=n;$("p0").textContent=s});
let cur=0,target=0,score=0;
const B1=bulbs("b1",n=>{cur=n;$("m1").textContent=""});
function nxt(){target=1+Math.floor(Math.random()*(score>=3?255:31));$("t1").textContent=target;B1.reset();cur=0;$("m1").textContent=""}
$("chk").onclick=()=>{const m=$("m1");if(cur===target){score++;$("sc").textContent=score;m.className="msg ok";m.textContent="¡Correcto! 🎉";setTimeout(nxt,900)}else{m.className="msg bad";m.textContent="Ahora suman "+cur+". ¡Inténtalo otra vez!"}};
$("nxt").onclick=nxt;nxt();
function name(){$("ch").innerHTML=[...$("nm").value].map(c=>"<div class='ch'><b>"+c.replace(/</g,"&lt;")+"</b>"+c.charCodeAt(0).toString(2).padStart(8,"0")+"</div>").join("")}
$("nm").oninput=name;name();
const px=Array(25).fill(0);
function gp(){$("gp").textContent=[0,1,2,3,4].map(r=>px.slice(r*5,r*5+5).join("")).join("\n")}
px.forEach((_,i)=>{const b=document.createElement("button");b.setAttribute("aria-label","Píxel "+(i+1));b.onclick=()=>{px[i]^=1;b.classList.toggle("on",!!px[i]);gp()};$("gr").appendChild(b)});gp();
